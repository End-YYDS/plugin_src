import{r as i}from"./index-Dy0yjznp.js";var f={exports:{}},n={};/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var u=i,a=Symbol.for("react.element"),c=Symbol.for("react.fragment"),d=Object.prototype.hasOwnProperty,m=u.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,y={key:!0,ref:!0,__self:!0,__source:!0};function x(t,e,l){var r,o={},s=null,p=null;l!==void 0&&(s=""+l),e.key!==void 0&&(s=""+e.key),e.ref!==void 0&&(p=e.ref);for(r in e)d.call(e,r)&&!y.hasOwnProperty(r)&&(o[r]=e[r]);if(t&&t.defaultProps)for(r in e=t.defaultProps,e)o[r]===void 0&&(o[r]=e[r]);return{$$typeof:a,type:t,key:s,ref:p,props:o,_owner:m.current}}n.Fragment=c;n.jsx=x;n.jsxs=x;f.exports=n;var _=f.exports;const v=()=>_.jsx("div",{className:"text-yellow-400 text-center text-3xl",children:"HelloWorld"}),E=()=>_.jsx(v,{});export{E as default,_ as j};
